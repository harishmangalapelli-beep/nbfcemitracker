# NBFC EMI Tracker

Single-page web + mobile app for EMI collection, overdue follow-ups, reminders and loan statements.
Static site: only `index.html`, no build step.

Demo PINs: Admin 1234, Staff 0000 (demo only, change before real use).
